//
//  ViewController.swift
//  mapKit1
//
//  Created by Mac on 6/26/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


struct Location {
    let title: String
    let latitude: Double
    let longitude: Double
}


class ViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var btnStandrd: UIButton!
    
    @IBOutlet weak var mapView: MKMapView!
    
    
    
    
    let locations = [
        Location(title: "Rajkot",    latitude: 22.3039, longitude: 70.8022),
        Location(title: "Bhavnagar", latitude: 21.7645, longitude: 72.1519),
        Location(title: "Ahmdabad",     latitude: 23.0225, longitude: 72.5714)
    ]

    
    var locationman = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnStandrd.layer.cornerRadius = 20
        btnStandrd.layer.backgroundColor = UIColor.gray.cgColor
        btnStandrd.layer.borderWidth = 1
        
        btn.layer.cornerRadius = 20
        btn.layer.backgroundColor = UIColor.darkGray.cgColor
        btn.layer.borderWidth = 1
        
       
            for location in locations {
                let annotation = MKPointAnnotation()
                annotation.title = location.title
                annotation.coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
                mapView.addAnnotation(annotation)
            }
        
        
//======================= single pin drop ============================
//        let location = CLLocationCoordinate2DMake(21.7614, 72.1275)
//        let span = MKCoordinateSpanMake(0.1, 0.1)
//        let region = MKCoordinateRegionMake(location, span)
//        mapView.setRegion(region, animated: true)
//
//        let flag = MKPointAnnotation()
//        flag.coordinate = location
//        flag.title = "Jalpesh Patel"
//        flag.subtitle = "HERE AT MY HOME...!!!"
//        mapView.addAnnotation(flag)
 //============================================================
        
        
    }
 
    
    
    @IBAction func btnStandard(_ sender: UIButton)
    
        {
            mapView.mapType = .standard
        
        
    }
    
    @IBAction func btnSatelite(_ sender: UIButton)
    {
        mapView.mapType = .satellite
        
    }
    
    

}
extension ViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        
        if !(annotation is MKPointAnnotation) {
            return nil
        }
        
        let reuseId = "test"
        
        var anView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
        if anView == nil {
            anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            
            anView?.canShowCallout = true
        }
        else {
            anView?.annotation = annotation
        }
       
        anView?.image = UIImage(named: "point2.png")
        return anView
    }
    

}
